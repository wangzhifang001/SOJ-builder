#!/bin/bash
su judger
cd /home/judger/
./judge_client start
exec bash