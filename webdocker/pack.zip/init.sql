ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'root';
CREATE DATABASE IF NOT EXISTS `soj` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;