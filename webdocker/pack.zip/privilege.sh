#!/bin/bash

chown www-data:www-data -R /var/www/soj/app/storage
chown www-data:www-data -R /var/www/soj/uploads
mkdir /var/uoj_data
mkdir /var/uoj_data/upload
chown www-data:www-data -R /var/uoj_data